<?php
    class Supplier_sales{
        var $db;

        //建構函式
        public function Supplier_sales(){
            $this->db = new WADB(SYSTEM_DBHOST, SYSTEM_DBNAME, SYSTEM_DBUSER, SYSTEM_DBPWD);
            return TRUE;
        }

        //判斷是否為經銷商業務人員
        public function getSupplier_sales_information($ssLogId,$ssPwd){
            $sql = "select
                        *
                    from
                        `supplier_sales`
                    where
                        `ssLogId`='".$ssLogId."'&&
                        `ssPwd` = '".$ssPwd."'
                    ";
            $data = $this->db->selectRecords($sql);
            return $data[0];
        }
    }
?>